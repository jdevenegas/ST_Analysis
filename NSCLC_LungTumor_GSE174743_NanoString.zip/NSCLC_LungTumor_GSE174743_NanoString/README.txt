Data generation details: profiling with the GeoMx Cancer Transcriptome Atlas RNA and Protein assays.

-Five NSCLC tumors 
-20-24 ROIs each tumor (similar to spots)
-tumor (PanCK+) and microenvironment (PanCK-) AOIs from each ROI
-223 AOIs total
-measured RNA expression in each AOI for 1700 genes (544 from safeTME cell profile matrix)
-measured matching marker protein expression (58 marker proteins)
-regions/AOIS with low-outlier expression signal strength were removed 




Dataset Details:

1. raw_rna.csv
-spatially resolved rna expression data
-1700 RNA x 223 AOIs

2. normalized_rna.csv
-spatially resolved rna expression data (1700x223)
-1700 RNA x 223 AOIs
-Normalized using signal-to-background method

3. raw_protein.csv
-223 AOIs x 58 marker proteins
-spatially resolved protein expression data (223x58)

4. normalized_protein.csv (223x58)
-223 AOIs x 58 marker proteins
-spatially resolved protein expression data (1700x223)
-Normalized using  signal-to-background method

5. segment_annotations.csv
-list the sample ids and their corresponding tissue # (subject/patient), and the AOI type (TME vs Tumor)

6. CellProfile_safeTME.csv 
- 906 genes x 18 cell types
-Cell profile matrix used by Nanostring for immune and stromal cell types found in tumors
-Created in part from lung tumor scRNA-seq  (GSE127465)
-appended lung-tumor tumor-specific profiles that were not in original safeTME cell profile matrix

7. Cell_MarkerProteins.xlsx
-102 matches
-protein-cell matches
